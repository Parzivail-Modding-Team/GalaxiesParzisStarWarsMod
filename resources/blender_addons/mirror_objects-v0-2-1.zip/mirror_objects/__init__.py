# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    "name": "Mirror objects",
    "author": "Yannick 'BoUBoU' Castaing",
    "description": "mirror selected objects regarding to the 3D cursor",
    "location": "View3D > UI > Tool panel",
    "doc_url": "",
    "warning": "",
    "category": "Object",
    "blender": (2,90,0),
    "version": (0,2,1)
}

# get addon name and version to use them automaticaly in the addon
Addon_Name = str(bl_info["name"])
Addon_Version = str(bl_info["version"])
Addon_Version = Addon_Version[1:8].replace(",",".")

### import modules ###
import bpy

### define global variables ###
debug_mode = False
separator = "-" * 20

### create functions ###
def function():
    pass

### create panels ###
# create panel UPPER_PT_lower
class OBJECT_PT_mirrorobjects(bpy.types.Panel):
    bl_label = f"{Addon_Name} - {Addon_Version}"
    bl_idname = "OBJECT_PT_mirrorobjects"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    
    def draw(self, context):
        layout = self.layout
        layout.operator("object.mirrorobjects",text="Mirror Objects",emboss=True,depress=False,icon="MOD_MIRROR")

### create operators ###        
class OBJECT_OT_mirrorobjects(bpy.types.Operator):
    bl_idname = "object.mirrorobjects"
    bl_label = Addon_Name
    bl_description = "mirror selected objects regarding to the 3D cursor"
    bl_options = {"REGISTER", "UNDO"}
    
    # redo panel = user interraction
    mirror_x_prop: bpy.props.BoolProperty(
            name = "Mirror X",
            description = "mirror object on X axis",
            default=False,
    )
    mirror_y_prop: bpy.props.BoolProperty(
            name = "Mirror Y",
            description = "mirror object on Y axis",
            default=True,
    )
    mirror_z_prop: bpy.props.BoolProperty(
            name = "Mirror Z",
            description = "mirror object on Z axis",
            default=False,
    )
    use_3D_cursor: bpy.props.BoolProperty(
            name = "Use 3D Cursor",
            description = "if checked, use the 3D cursor as pivot, otherwise use world origin",
            default=True,
    )


    def execute(self, context):
        print(f"\n {separator} Begin {Addon_Name} {separator} \n")        

        # mirror_x = False
        # mirror_y = True
        # mirror_z = False

        # selected objects
        sel_obj = bpy.context.selected_objects
        #print(f"{sel_obj=}")
        if self.use_3D_cursor == True:
            pivot_loc = bpy.context.scene.cursor.location
        else:
            pivot_loc = [0,0,0]

        all_sel_obj = []
        for obj in sel_obj:
            #print(f"{obj=}")
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
            bpy.ops.object.duplicate_move_linked(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(0, 0, 0), "orient_type":'GLOBAL', "orient_matrix":((0, 0, 0), (0, 0, 0), (0, 0, 0)), "orient_matrix_type":'GLOBAL', "constraint_axis":(False, False, False), "mirror":False, "use_proportional_edit":False, "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "use_proportional_connected":False, "use_proportional_projected":False, "snap":False, "snap_target":'CLOSEST', "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "cursor_transform":False, "texture_space":False, "remove_on_cancel":False, "release_confirm":False, "use_accurate":False, "use_automerge_and_split":False})
            #get active object
            new_object = bpy.context.view_layer.objects.active
            new_object.select_set(True)
            #print(f"{new_object=}")
            bpy.ops.transform.mirror(orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(self.mirror_x_prop, self.mirror_y_prop, self.mirror_z_prop))
            if self.mirror_x_prop == True:
                new_object.location.x += (pivot_loc[0]-obj.location.x)*2
            if self.mirror_y_prop == True:
                new_object.location.y += (pivot_loc[1]-obj.location.y)*2
            if self.mirror_z_prop == True:
                new_object.location.z += (pivot_loc[2]-obj.location.z)*2
            all_sel_obj.append(obj)
            all_sel_obj.append(new_object)

        # get the complete selection
        bpy.ops.object.select_all(action='DESELECT')
        for obj in all_sel_obj:
            obj.select_set(True)
        new_object = bpy.context.view_layer.objects.active

        print(f"{Addon_Name} done on : {sel_obj}\n")
        print(f"\n {separator} {Addon_Name} Finished {separator} \n")
        
        return {"FINISHED"}


# list all classes
classes = (
    OBJECT_PT_mirrorobjects,
    OBJECT_OT_mirrorobjects,
    )

# register classes
def register():
    for cls in classes:
        bpy.utils.register_class(cls)

#unregister classes 
def unregister():    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

        