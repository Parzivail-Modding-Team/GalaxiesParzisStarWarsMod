class DebugException(Exception):
    pass
